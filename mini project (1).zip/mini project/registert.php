<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>teacher signup</title>
	<link rel="stylesheet" type="text/css" href="sighup.css">
</head>
<body>
<div class="wrapper">
	<nav class="navbar">
			<img src="logoo.png" class="logo">
			<ul>
				<li><a href="homepage.php" class="activ">HOME</a></li>
				<li><a href="prac.php">FEATURES</a></li>
				<li><a href="about.php">ABOUT</a></li>
			</ul>
			
		</nav>
		
		
		<div style="background:red ; margin-top:50px; margin-left:50px;padding-left:10px; width:440px"><?php include('errors.php') ?></div>
		
		</div>
		</div>





	<div class="wrap">
		<form  method="post" action="registert.php" onsubmit="return checkPassword(this)">

			<div class="container">
				<i style="text-align: center; margin-top: 6px; border-radius: 40px; " class="fa fa-user-circle icon"></i>
				<h1>Signup</h1>
				<h2>(Teacher)*</h2>
				<hr size="4" width="100%" color="#4caf50">
				<label for="name"><b>username</b></label>
				<input type="text" name="username" id="name" placeholder="First & Last name" value="<?php echo $username; ?>" required>
				<span id="name"></span>

				<lable for="email"><b>Email</b></label>
				<input value="<?php echo $username; ?>" type="text" name="email" id="email" placeholder="Enter Email" required>
				<span id="text"></span>
				<lable ><b>Password</b></label>
                <input type="Password" name="password_1" placeholder="Enter Password">
                <lable ><b> ConformPassword</b></label>
				<input type="Password" name="password_2" placeholder="Renter Password">
				
   				<div class="input-group">
			<button type="submit" class="btn" name="reg_usert">Register</button>
			<p>
			Already a member ? <a href="logint.php">Login Up</a>
		</p>
		</div>
	</p></div>
	
</body>
</html>