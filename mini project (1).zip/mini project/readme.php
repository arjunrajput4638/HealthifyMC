<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>read me </title>
	<link rel="stylesheet" type="text/css" href="readme.css">
</head>
<body>
	<div class="wrapper">
		<nav class="navbar">
			<img src="logoo.png" class="logo">
			<ul>
				<li><a href="loginway.php" class="bc">login</a></li>
				<li><a href="homepage.php" class="activ">HOME</a></li>
				<li><a href="features.php">FEATURES</a></li>
				<li><a href="about.php">ABOUT</a></li>
				
			</ul>
			
		</nav>
		<div class="center">
			<h2>Why is emotional and mental health important? </h2>
			<h3 class="stuff">
				Emotional and mental health is important because it’s a vital part of your life and impacts your thoughts, behaviors and emotions. Being healthy emotionally can promote productivity and effectiveness in activities like work, school or caregiving. It plays an important part in the health of your relationships, and allows you to adapt to changes in your life and cope with adversity.
			</h3>
			<h2>How can you improve your emotional health day-to-day?</h2>
			<h3 class="stuff">There are steps you can take to improve your mental health everyday. Small things like exercising, eating a balanced and healthy meals, opening up to other people in your life, taking a break when you need to, remembering something you are grateful for and getting a good night’s sleep, can be helpful in boosting your emotional health.</h3>
			<img src="imagemind.jpg" class="brain">
			
			
            <h2>When is a good time to reach out for help?</h2>
			<h3 class="stuff">Issues related to mental health can impact different people in different ways. If you start to see changes in your overall happiness and relationships, there are always ways get the support you want. Here are some ways you can get help:
			</h3>
			<ul>
				<li>
					<h2 class="red">
					  &nbsp Connect with other individuals, friends and family — <h3 class="stuff">Reaching out and opening up to other people in your life can help provide emotional support.</h3></h1>
				</li>
				<li><h2 class="red">
					  &nbsp Learn more about mental health — <h3 class="stuff">There are many resources you can turn to for learning more about emotional health. Some examples include Psychology Today, National Institute of Mental Health, and Anxiety and Depression Association of America.</h3></h1></li>
				<li><h2 class="red">
					  &nbsp Take a mental health assessment — <h3 class="stuff">An assessment can help determine if stress, anxiety or depression may be having an impact on your life. Doctor On Demand offers a free and private online mental health assessment that you can take at any time.</h3></h1></li>
				<li><h2 class="red">
					  &nbsp Talk to a professional —  <h3 class="stuff"> If you start to feel like your emotional health is starting to impact you, it may be time to reach out for extra support. With Doctor On Demand, you can see a psychologist or psychiatrist and find the personalized support you want.</h3></h1></li>
			</ul>
			<br>
			<h3 class="stuff">&nbsp &nbsp &nbsp &nbspLastly, you can also learn more about taking care of your mental health on our blog. Discover ways to take a healthy approach to your emotional wellness, as well as understand issues like depression and how it can affect men and women differently. Read more articles by our caring team of psychologists and psychiatrists here to help support a healthy mind and lifestyle.</h3>
			


		</div>
		
</body>
</html>