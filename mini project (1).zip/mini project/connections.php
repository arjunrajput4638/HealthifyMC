<?php

	$db=mysqli_connect("localhost","root","","register");  
					/* server name, username, passwor, database name */

?>