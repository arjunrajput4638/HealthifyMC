<?php 
session_start(); 
include "db_conn.php";

    $name = ($_POST['name']);
	$uname = ($_POST['uname']);
	$dob = ($_POST['dob']);
    
    $num = ($_POST['num']);
    $fathername = ($_POST['fathername']);
    $fanum = ($_POST['fanum']);
    $state = ($_POST['state']);
    $city = ($_POST['city']);
    $house = ($_POST['house']);
    $proof = ($_POST['proof']);
    
	

    $user_check_query = "SELECT * FROM formpage WHERE uname='$uname' LIMIT 1";
	$result11 = mysqli_query($conn, $user_check_query);
	$user = mysqli_fetch_assoc($result11);

	// Checking user in database
	if ($user) {

		if ($user['uname'] === $uname) {
			array_push($errors, "Email already exists");
		}
	}
	
		// hashing the password
        

	    $sql = "SELECT * FROM formpage WHERE uname='$uname' ";
		$result = mysqli_query($conn, $sql);

		
           $sql2 = "INSERT INTO formpage( name, uname,dob,contact,fathername,fathercontact,state,city,house,
 proof) VALUES( '$name','$uname','$dob', '$num ','$fathername','$fanum','$state','$city','$house','$proof')";
           $result2 = mysqli_query($conn, $sql2);
           if ($result2) {
           	 header("Location: signup.php?success=Your account has been created successfully");
	         exit();
           }else {
	           	header("Location: signup.php?error=unknown error occurred");
		        exit();
           }
?>