<?php
	session_start();

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: logint.php');
	}
	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: logint.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>home page</title>
	<link rel="stylesheet" type="text/css" href="selection.css">
</head>
<body>
	<script type="text/javascript">

    alert("Kindly fill the from first to continue the site*")
    </script>
	<div class="wrapper">
		<nav class="navbar">
			<img src="logoo.PNG" class="logo">
			<ul>
				<li><div class="content">
					<?php if (isset($_SESSION['success'])) : ?>
						<div class="error success">
							<h3>
								<?php 
								echo $_SESSION['success'];
								unset($_SESSION['success']);
								?>
							</h3>
						</div>
					<?php endif ?>
					<?php if (isset($_SESSION['username'])) : ?>
						<p> <a href="index.php?logout='1'" style="font-size: 20px;font-family: Brush Script MT;">logout</a></p>
					<?php endif ?>
					</div>
				</li>
				<li><a href="#" class="acti">HOME</a></li>
				<li><a href="features.html">FEATURES</a></li>
				<li><a href="about.html">ABOUT</a></li>
			</ul>
		</nav>
		<div class="center">
			<div class="buttons">
				<label style="font-family: Brush Script MT; font-size: 40px; margin-top: 40px">Quick questions about website</label>
				
				<button onclick=window.location.href="readme.html" style="margin-right: 1100px; width: 400px; margin-bottom: 10px;">What Healthify MC is?</button><br>
				<button onclick=window.location.href="https://www.mayoclinic.org/diseases-conditions/mental-illness/symptoms-causes/syc-20374968" style=" width: 400px; margin-bottom: 10px;">Mental illness - Symptoms and causes</button><br>
				<button onclick=window.location.href="https://www.nami.org/Your-Journey/Living-with-a-Mental-Health-Condition/What-to-Do-In-a-Crisisl" style=" width: 400px; margin-bottom: 10px;">What to do in a Crisis</button><br>
				<button onclick=window.location.href="https://www.google.com/amp/s/www.yogajournal.com/.amp/lifestyle/5-ways-yoga-is-good-for-your-mental-health" style=" width: 400px; margin-bottom: 10px;">Is Yoga good for Mental health acre</button><br>

				<button onclick=window.location.href="https://www.healthline.com/health/depression/depression-motivation-tips" style=" width: 400px; margin-bottom: 10px;">How Motivation help to Depression</button><br>
				<button onclick=window.location.href="https://www.webmd.com/depression/guide/causes-depression" style=" width: 400px; margin-bottom: 10px;">What are the causes od depression?</button><br>
				<a href="chating.php">
         				<img alt="form" src="chat.jpg" style="margin-right: 500px;  height: 250px; width: 350px; border-radius: 100px ; box-shadow: 0px 0px 10px 1px grey; bacground:red;" >
         						
								
				
			</div>
		</div>
		<div class="center">
			<div class="button">
				<div>
					<table>
						<tr>
							<th>
								<a href="signup.php">
         						<img alt="form" src="form.jpg" style="margin-left: 350px; margin-right: 150px ;margin-bottom: 70px;height: 260px; width: 360px ; box-shadow: 0px 0px 10px 1px grey; border-radius: 30px " ></th>
         						
								
							<th>
								<a href="quiz.php">
         						<img alt="start" src="quiz.jpg" style=" height: 260px;margin-bottom: 70px; width: 360px;box-shadow: 0px 0px 10px 1px grey; border-radius: 30px " ></th>
         						
								</tr>
						

						<tr>
							<th>
								<a href="meditation.php">
         						<img alt="index" src="exercise.jpg" style="350px; margin-right: 150px ; height: 260px; width: 360px;margin-left:330px; box-shadow: 0px 0px 10px 1px grey; border-radius: 30px " >
         					</th>
         					<th>
         						<a href="profile.php">
         						<img alt="form" src="profile.jpg" style=" height: 260px; width: 360px; box-shadow: 0px 0px 10px 1px ;grey border-radius: 30px ; border-radius: 30px " ></th>
							</tr>
					</table>
         				
         				
         				
         		</div>
			</div>
		</div>
		<div class="center">
			<div class="button">
				
			</div>
		</div>
		<div class="l1"></div>
		
</body>
</html>
