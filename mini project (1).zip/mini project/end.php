<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>JavaScript Quiz</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-circle-progress/1.2.2/circle-progress.min.js"></script>
    <!-- style.css -->
    <link rel="stylesheet" href="dist/css/style.css">
</head>
<body>
    <div class="wrapper">
        <div class="all">
           <i class="fas fa-award award_icon"></i>
           <h3 class="username">well done! <span class="name"></span></h3>
           <div class="gauge">
              <div class="gauge__body">
                <div class="gauge__fill"></div>
                <div class="gauge__cover"></div>
              </div>
            </div>
           <p class="userpoints">Your Points <span class="points"></span></p>
         <p class="usertime"> Time taken <span class="time_taken"></span></p>
         <a href="index.php" style="box-shadow: 0px 0px 10px 1px grey;color:black ;padding: 5px 13px;font-size: 25px;border-radius: 25px; margin-left:100px: margin-top:50px">back</a>
        </div>
    </div>

    <script src="https://kit.fontawesome.com/d56261bbb9.js"></script>

        <!-- user info -->
        <script src="dist/js/userInfo.js"></script>


    </script>
     <div class="back">
        <div class="tab">
            <h2 >Drepession Scoring </h2>
            <table><tr>
                <th>Score ranges</th>
                <th>You may have </th>
            </tr>
            <tr>
                <th>50 & above </th>
                <th>No depression</th>
            </tr>
            <tr>
                <th>34 - 49</th>
            <th>Possible mild depression</th>
            </tr>
            <tr>
                <th>21 - 33</th>
                <th> Borderline depression</th>
            </tr>
            <tr>
                <th>18 - 20</th>
                <th>Mild to moderate</th>
            </tr>
            <tr>
                <th>10 - 17</th>
                <th>Moderate to severe</th>
            </tr>
            <tr>
                <th>0 - 9</th>
                <th>Severe depression</th>
            </tr>
    </table>
    </div>
</body>
</html>
