<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>home page</title>
	<link rel="stylesheet" type="text/css" href="homepage.css">
</head>
<body>
	<div class="wrapper">
		<nav class="navbar">
			<img src="logoo.PNG" class="logo">
			<ul>
				<li><a href="loginway.php" class="bc">login</a></li>
				<li><a href="#" class="active">HOME</a></li>
				<li><a href="features.php">FEATURES</a></li>
				<li><a href="about.php">ABOUT</a></li>
				
			</ul>
			
		</nav>
		<div class="center">
			<h1>Healthify mind care </h1>
			<h2>Mental health…is not a destination, but a process. It’s about how you drive, not where you’re going.</h2>
			<div class="buttons">
				<button onclick=window.location.href="readme.php">Read More</button>
				<button class="b">Contact Us</button>
			</div>
		</div>
	</div>

</body>
</html>