<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>home page</title>
	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
	<div class="wrapper">
		<nav class="navbar">
			<img src="logoo.png" class="logo">
			<ul>
				<li><a href="homepage.php" >HOME</a></li>
				<li><a href="features.php">FEATURES</a></li>
				<li><a href="about.php">ABOUT</a></li>
				
			</ul>
			
		</nav>
		<div class="center">
			<h1>login here </h1>
			<h2>what do i do here?</h2>
			<h2>here you need to register with your Name,
			Email address to kick start registration process</h2>
			<div class="buttons">
				
				<button onclick=window.location.href="login.php">Login as student</button>
				<button onclick=window.location.href="logint.php" class="b">Login as trainer</button>
			</div>
		</div>
	</div>

</body>
</html>