-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2020 at 05:51 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `contact` varchar(25) NOT NULL,
  `fathername` varchar(100) NOT NULL,
  `fathercontact` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `house` varchar(100) NOT NULL,
  `proof` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`id`, `name`, `uname`, `dob`, `contact`, `fathername`, `fathercontact`, `state`, `city`, `house`, `proof`) VALUES
(1, 'rizmi sowdhagar', 'rizmi@gmail.com', '29 March,2019', '9640752559', 'abc', '123', 'TN', 'hyd', 'def', '0123456789');

-- --------------------------------------------------------

--
-- Table structure for table `formpage`
--

CREATE TABLE `formpage` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `contact` varchar(25) NOT NULL,
  `fathername` varchar(100) NOT NULL,
  `fathercontact` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `house` varchar(100) NOT NULL,
  `proof` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `formpage`
--

INSERT INTO `formpage` (`id`, `name`, `uname`, `dob`, `contact`, `fathername`, `fathercontact`, `state`, `city`, `house`, `proof`) VALUES
(1, 'rizmi sowdhagar', 'rizmi@gmail.com', '29 March,2019', '9640752559', 'abc', '123', 'TN', 'hyd', 'def', '0123456789'),
(13, 'yuvraj thakur', 'arjunsinghthakur770@gmail.com', '25 march 2000', '+916005044194 ', 'arjunhiujnhj', '1234567890', 'Jammu and Kashmir', 'jammu', '123house', '12345678'),
(14, 'najeeb singh', 'najeebsingh770@gmail.com', '25 march 2000', '+916005044194 ', 'varun', '1234567834', 'Jammu and Kashmir', 'jammu', '3456ertydfghxcvgertgh', '234567876543');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(20) NOT NULL,
  `name` text NOT NULL,
  `ke` text NOT NULL,
  `avatar` varchar(500) NOT NULL,
  `message` text NOT NULL,
  `image` varchar(500) NOT NULL,
  `tipe` varchar(200) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `ke`, `avatar`, `message`, `image`, `tipe`, `date`) VALUES
(1, 'bachors', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', 'Awesome â¤ï¸ https://github.com/bachors/Chat-Realtime', '', 'rooms', '2018-08-30 09:21:19'),
(1, 'bachors', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', 'Awesome â¤ï¸ https://github.com/bachors/Chat-Realtime', '', 'rooms', '2018-08-30 09:21:19'),
(1, 'bachors', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', 'Awesome â¤ï¸ https://github.com/bachors/Chat-Realtime', '', 'rooms', '2018-08-30 09:21:19'),
(1, 'bachors', 'Public', 'hello here i am avtar', 'Awesome â¤ï¸ https://github.com/bachors/Chat-Realtime', '', 'rooms', '2018-08-30 09:21:19'),
(0, 'arjunrajput4638', 'bachors', 'https://avatars3.githubusercontent.com/u/4948333', 'heyaa this is arjun here', '', 'users', '2020-11-21 19:17:47'),
(0, 'arjunrajput4638', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', 'helloollo', '', 'rooms', '2020-11-21 19:48:37'),
(0, 'rizmi', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', '123456\n', '', 'rooms', '2020-11-21 19:50:08'),
(0, 'deed', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', '2345\n', '', 'rooms', '2020-11-21 20:13:05'),
(0, '1234', 'arjunrajput4638', 'https://avatars3.githubusercontcom/u/4948333', '123456789', '', 'users', '2020-11-21 20:25:09'),
(0, 'pagalman', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', 'heyaa public dou think i am pagal', '', 'rooms', '2020-11-22 00:49:36'),
(0, 'pagalman', 'rizmi', 'https://avatars3.githubusercontent.com/u/4948333', 'heyaa rizmi i love calling you pomalo and no doubt you are cute', '', 'users', '2020-11-22 00:51:41'),
(0, 'pagalman', 'rizmi', 'https://avatars3.githubusercontent.com/u/4948333', 'juju', '', 'users', '2020-11-22 00:52:49'),
(0, 'rizmi', 'arjunrajput4638', 'https://avatars3.githubusercontent.com/u/4948333', 'dfgyxcvgh', '', 'users', '2020-11-22 00:54:03'),
(0, 'yuvraj', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', '123456wertysdfghxcvb', '', 'rooms', '2020-11-22 14:07:37'),
(0, 'yuvraj', 'rizmi', 'https://avatars3.githubusercontent.com/u/4948333', '234567wertysdfgh', '', 'users', '2020-11-22 14:07:48'),
(0, 'yuvraj', 'arjunrajput4638', 'https://avatars3.githubusercontent.com/u/4948333', 'bhai tu tu pro hai', '', 'users', '2020-11-22 14:08:06'),
(0, 'najeeb', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', 'hey evry one thus is jnajeeb', '', 'rooms', '2020-11-22 19:58:38'),
(0, 'najeeb', 'yuvraj', 'https://avatars3.githubusercontent.com/u/4948333', 'pahal jbhdsvhuw uhbsduf', '', 'users', '2020-11-22 19:59:16'),
(0, 'najeeb', 'pagalman', 'https://avatars3.githubusercontent.com/u/4948333', 'rdtyguhijdxfcgvhbjn', '', 'users', '2020-11-22 19:59:24'),
(0, 'najeeb', 'arjunrajput4638', 'https://avatars3.githubusercontent.com/u/4948333', '5678tdrfyugihfgcvhbj', '', 'users', '2020-11-22 19:59:32'),
(0, 'mamta', 'Public', 'https://avatars3.githubusercontent.com/u/4948333', 'hey students thus is your ,am', '', 'rooms', '2020-11-22 20:01:10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(13, 'arjun', 'arjunsinghthakur770@gmail.com', '202cb962ac59075b964b07152d234b70'),
(14, 'fik', 'fik', '202cb962ac59075b964b07152d234b70'),
(15, 'rizmi', 'rizmi', 'a01610228fe998f515a72dd730294d87'),
(16, 'dikshant ', 'dikshant ', 'c20ad4d76fe97759aa27a0c99bff6710'),
(17, 'admin', 'arjunhakur770@gmail.com', '202cb962ac59075b964b07152d234b70'),
(18, 'rizmi3456erty', 'rizmi56rty', '202cb962ac59075b964b07152d234b70'),
(19, 'shivani', 'ahivani123@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
(20, 'yuvraj', 'yuvrajisking', '202cb962ac59075b964b07152d234b70'),
(21, 'najeeb', 'najeeb123@gmail.com', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `usersl`
--

CREATE TABLE `usersl` (
  `ke` int(20) NOT NULL,
  `name` text NOT NULL,
  `avatar` varchar(500) NOT NULL,
  `login` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usersl`
--

INSERT INTO `usersl` (`ke`, `name`, `avatar`, `login`, `status`) VALUES
(1, 'bachors', 'hello here i am avtar', '2018-08-30 09:21:27', 'online'),
(0, 'arjunrajput4638', 'https://avatars3.githubusercontent.com/u/4948333', '2020-11-21 19:17:26', 'online'),
(0, '1234', 'https://avatars3.githubusercontcom/u/4948333', '2020-11-22 00:40:02', 'offline'),
(0, 'rizmi', 'https://avatars3.githubusercontent.com/u/4948333', '2020-11-22 14:07:04', 'offline'),
(0, 'pagalman', 'https://avatars3.githubusercontent.com/u/4948333', '2020-11-22 00:52:56', 'offline'),
(0, 'yuvraj', 'https://avatars3.githubusercontent.com/u/4948333', '2020-11-22 14:09:01', 'offline'),
(0, 'najeeb', 'https://avatars3.githubusercontent.com/u/4948333', '2020-11-22 19:58:17', 'offline'),
(0, 'mamta', 'https://avatars3.githubusercontent.com/u/4948333', '2020-11-23 10:19:01', 'online');

-- --------------------------------------------------------

--
-- Table structure for table `usersteacher`
--

CREATE TABLE `usersteacher` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usersteacher`
--

INSERT INTO `usersteacher` (`id`, `username`, `email`, `password`) VALUES
(1, 'admin', 'admin', 'admin'),
(2, 'rizmi', 'arjunsinghthakur70@gmail.com', '202cb962ac59075b964b07152d234b70'),
(3, 'rizmi', 'rizmi', '202cb962ac59075b964b07152d234b70'),
(4, 'rizmi', 'arjunhthakur770@gmail.com', '202cb962ac59075b964b07152d234b70'),
(5, 'rizmi', 'unsinghthakur770@gmail.com', '202cb962ac59075b964b07152d234b70'),
(6, 'rizmi', 'rizmiaa', '202cb962ac59075b964b07152d234b70'),
(7, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(8, 'ar', 'ar@', 'c582dec943ff7b743aa0691df291cea6'),
(9, 'dikshant', 'dakshant@557gmail.com', '4297f44b13955235245b2497399d7a93'),
(10, 'admin1', 'admin1', '202cb962ac59075b964b07152d234b70'),
(11, 'rizmi5', 'rizmi5', '81dc9bdb52d04dc20036dbd8313ed055'),
(12, 'arjunsinghthakur.si20@iacademia.in', 'arjunsinghthakur770@gmail.com', '202cb962ac59075b964b07152d234b70'),
(13, 'rizmi45', 'rizmi45', '202cb962ac59075b964b07152d234b70'),
(14, 'mamta', 'mamta123@gmail.com', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formpage`
--
ALTER TABLE `formpage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usersteacher`
--
ALTER TABLE `usersteacher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `formpage`
--
ALTER TABLE `formpage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `usersteacher`
--
ALTER TABLE `usersteacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
