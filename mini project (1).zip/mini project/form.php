<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>teacher signup</title>
	<link rel="stylesheet" type="text/css" href="sighup.css">
</head>
<body>
	<div class="wrap">
		<form  method="post" action="form.php" onsubmit="return checkPassword(this)">

		<div class="container">
				<h1>Form</h1>
				<hr size="4" width="100%" color="#4caf50">
				<table>
					<tr>
						<th>First name</th>
						<th>Last name</th>
					</tr>
					<tr>
						<th><input type="text" id="name" placeholder="First name" name="firstname" style="width: 231px;" required></th>
						<span id="name"></span>
						<th><input type="text" id="name" placeholder="Last name" name="lastname" style="width: 231px;" required></th>
						<span id="name"></span>
					</tr>
				</table>
				<span id="name"></span>
				<lable for="email"><b>Email</b></label>
				<input type="text" name="email" id="email" placeholder="Enter Email" required>
				<span id="text"></span>
				<table>
					<tr>
						<th>
							<div ><th><form action="">
								<tr><input type="radio" name="gender" value="male" name="gender" value="m"> Male</tr>
								<tr><input type="radio" name="gender" value="female" name="gender" value="g"> Female</tr>
								<tr><input type="radio" name="gender" value="other" name="gender" value="o"> Other</tr></form>
							</div>
						</th>
					</tr>
					<th>Date of birth</th>
					<th><input type="date"  style="margin-left: 40px" name="dateofbirth"></th>
					<tr>						
					</tr>
				</table>
				<lable ><b>Contact Number*</b></label>
                <input type="Password" id="tel"  name="contact" placeholder="Enter your contact number">
                <span id="tel"></span>

                <lable ><b>Father/gardener Name</b></label>
                <input type="Password" name="fathername" placeholder="Enter Father/gardener Name">
                <lable ><b>Father Name contact</b></label>
                <input type="Password" name="fathercontact" placeholder="Enter Father/gardener Name Contact">
                <lable ><b>Address</b></label><br>
                <table>
                	<tr>
                		State
                	</tr>
                	<tr><input name="state" type="text"  style="width: 231px; margin-right: 180px;" placeholder="state"></tr>
                	<tr>
                		City
                	</tr>
                	<tr><input name="city" type="text" style="width: 231px; margin-right: 180px" placeholder="City"></tr>
                	<tr>
                		House no.
                	</tr>
                	<tr><input name="house" type="text" style="width: 311px; margin-right: 61px" placeholder="House no."></tr>
                </table>
                <lable><b>Government Id Proof*</b></label><br>
                <table>
                	<tr><select id="Id proof" name="Proof">
                		<option value="Adhar card">Adhar card</option>
    					<option value="Driving licence">Driving licence</option>
    					<option value="Pan card">Pan card</option>
  					</select></tr>
                	<tr><input type="text" name="proof" placeholder="Id number" style="margin-right: 140px ;width:200px;"></tr>
                </table>
                <button type="submit" class="btn" name="reg_f" >Submit</button>
            </form>
				
	</p></div>
	
</body>
</html>