
<?php 
session_start();

 ?>
 <!DOCTYPE html>
<html>
<head>
	<title>FORM PAGE</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>

     <form style="height: 1500px;margin-top: 50%;margin-bottom: 5%; " action="signup-check.php" method="post">
     	<h2>SIGN UP</h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

          <?php if (isset($_GET['success'])) { ?>
               <p class="success"><?php echo $_GET['success']; ?></p>
          <?php } ?>

          <label>FullName</label>
          <?php if (isset($_GET['name'])) { ?>
               <input type="text" 
                      name="name" 
                      placeholder="FullName"
                      value="<?php echo $_GET['name']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="name" 
                      placeholder="FullName"><br>
          <?php }?>

          <label>Email</label>
          <?php if (isset($_GET['uname'])) { ?>
               <input type="email" 
                      name="uname" 
                      placeholder="Email"
                      value="<?php echo $_GET['uname']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="uname" 
                      placeholder="Email Id"><br>
          <?php }?>

          <label>Date of Birth</label>
          <?php if (isset($_GET['dob'])) { ?>
               <input type="text" 
                      name="dob" 
                      placeholder="Date Of Birth"
                      value="<?php echo $_GET['dob']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="dob" 
                      placeholder="Date of Birth"><br>
          <?php }?>

          <label>Contact Number</label>
          <?php if (isset($_GET['num'])) { ?>
               <input type="text" 
                      name="num" 
                      placeholder="Contact Number"
                      value="<?php echo $_GET['num']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="num" 
                      placeholder="Contact Number"><br>
          <?php }?>

          <label>Father's Name</label>
          <?php if (isset($_GET['fathername'])) { ?>
               <input type="text" 
                      name="fathername" 
                      placeholder="Father's Name"
                      value="<?php echo $_GET['fathername']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="fathername" 
                      placeholder="Father's Name"><br>
          <?php }?>

          <label>Father's Number</label>
          <?php if (isset($_GET['fanum'])) { ?>
               <input type="text" 
                      name="fanum" 
                      placeholder="Father's Number"
                      value="<?php echo $_GET['fanum']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="fanum" 
                      placeholder="Father's Number"><br>
          <?php }?>
          <label>State</label>
          <?php if (isset($_GET['state'])) { ?>
               <input type="text" 
                      name="state" 
                      placeholder=" State"
                      value="<?php echo $_GET['state']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="state" 
                      placeholder="State"><br>
          <?php }?>

          <label>City</label>
          <?php if (isset($_GET['city'])) { ?>
               <input type="text" 
                      name="city" 
                      placeholder="City"
                      value="<?php echo $_GET['city']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="city" 
                      placeholder="City"><br>
          <?php }?>

          <label>House No.</label>
          <?php if (isset($_GET['house'])) { ?>
               <input type="text" 
                      name="house" 
                      placeholder="House No."
                      value="<?php echo $_GET['house']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="house" 
                      placeholder="House No."><br>
          <?php }?>

          <lable><b>Government Id Proof*</b></label><br>
                <table>
                  <tr><select id="Id proof" name="proof">
                    <option value="Adhar card">Adhar card</option>
              <option value="Driving licence">Driving licence</option>
              <option value="Pan card">Pan card</option>
            </select></tr><br>
                 <label>Proof</label>
          <?php if (isset($_GET['proof'])) { ?>
               <input type="text" 
                      name="proof" 
                      placeholder="PROOF"
                      value="<?php echo $_GET['proof']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="proof" 
                      placeholder="Proof"><br>
          <?php }?>
                </table>


     
     	<button type="submit">Sign Up</button>
          <a href="index.php" class="ca">Already have an account?</a>
          <div class="back" style="margin-left:120px ; margin-top:20px">
          <a href="index.php" class="action">BACK TO MAIN</a>
     </div>
     </form>
</body>
</html>