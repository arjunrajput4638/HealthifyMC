<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>read me </title>
	<link rel="stylesheet" type="text/css" href="about.css">
</head>
<body>
	<div class="wrapper">
		<nav class="navbar">
			<img src="logoo.png" class="logo">
			<ul>
				<li><a href="loginway.php" class="bc">login</a></li>
				<li><a href="homepage.php" >HOME</a></li>
				<li><a href="features.php"  >FEATURES</a></li>
				<li><a href="#" class="active">ABOUT</a></li>
				
			</ul>
			
		</nav>
		<div class="center">
			<h2 class="stuff">
				<li>The web application main motto is to cure the people who are mentally ill through virtual communication.</li>
				<li>This application firstly seeks basic information of an user like email, mobile number, address etc.</li>
				<li> Assessment test will be conducted to assess whether a person is mentally ill or not.</li>
				<li>The person who needs assistance will be guided by an admin who will try to cure them.</li>
				<li>This is the basic functionality of this web application.</li>
			</h3>

		</div>
	</div>

</body>
</html>