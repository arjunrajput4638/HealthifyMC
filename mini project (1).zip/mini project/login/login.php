<?php 
session_start(); 
include "db_conn.php";
  

        
		$sql = "SELECT * FROM users WHERE uname='$uname' AND pass='$pass'";

		$result = mysqli_query($conn, $sql);

		

    if(!$row = $result->fetch_assoc()) {
      echo "<script>";
      echo"alert('incorrect email or password')";
      echo "</script>";
    }else {

       
        header("Location: home.php");
      }
?>