<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
     <form action="login.php" method="post">
     	<h2>LOGIN</h2>
     	
     	<label>Email</label>
     	<input type="text" name="uname" placeholder="Email"><br>

     	<label>Password</label>
     	<input type="password" name="pass" placeholder="Password"><br>

     	<a href='home.php'><button type="submit">Login</button></a>
          <a href="signup.php" class="ca">Create an account</a>
     </form>
</body>
</html>