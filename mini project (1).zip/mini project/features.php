
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>read me </title>
	<link rel="stylesheet" type="text/css" href="features.css">
</head>
<body>
	<div class="wrapper">
		<nav class="navbar">
			<img src="logoo.png" class="logo">
			<ul>
				<li><a href="loginway.php" class="bc">login</a></li>
				<li><a href="homepage.php" >HOME</a></li>
				<li><a href="#" class="active">FEATURES</a></li>
				<li><a href="about.php">ABOUT</a></li>
				
			</ul>
			
		</nav>
		<div class="center">
			
			<h2 class="stuff">
				<li>This web application is user-friendly. Any person can access this without any difficulties.</li>
				<li>The application is light weighted one in terms of memory utilization.</li>
				<li>The UI is highly attractive one.</li>
				<li>The response time is minimum and data transmission occurs in fraction of seconds.</li>
				<li>This application is highly secure. The data given by the user is fully encrypted and it cannot be hacked.</li>			
			</h3>

		</div>
	</div>

</body>
</html>