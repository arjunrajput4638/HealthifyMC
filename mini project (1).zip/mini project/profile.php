<?php
$username = "root";
$password = "password";
$database = "register";
$mysqli = new mysqli("localhost", $username, "", $database);

$query = "SELECT * FROM formpage ORDER BY id DESC LIMIT 1";
echo "<b><center>USER PROFILE</center> </b> <br> <br>";

if ($result = $mysqli->query($query)) {

    while ($row = $result->fetch_assoc()) {
        $field1name = $row["name"];
        $field2name = $row["uname"];
        $field3name = $row["dob"];
        $field4name = $row["contact"];
        $field5name = $row["fathername"];
        $field6name = $row["fathercontact"];
        $field7name = $row["state"];
        $field8name = $row["city"];
        $field9name = $row["house"];
        $field10name = $row["proof"];






        echo '<a href="index.php" style="box-shadow: 0px 0px 10px 1px grey; padding: 5px 13px;font-size: 25px;border-radius: 25px; margin-left:50px: margin-top:500px">back</a>';

        echo '<img style="height: 200px; width: 200px; margin-left: 580px;" src="profilepic3.jpg">';

        echo '<div style=" margin-left: 600px; margin-top: 40px">';
        echo "<b>";
 				echo "<table  class='table table-bordered' >";
	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b> FULL NAME : </b>";
	 					echo "</td>";

	 					echo "<td>";
	 						echo $field1name;
	 					echo "</td>";
	 				echo "</tr>";

	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b> EMAIL </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $field2name ;
	 					echo "</td>";
	 				echo "</tr>";

	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b> DATE OF BIRTH : </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $field3name;
	 					echo "</td>";
	 				echo "</tr>";

	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b> CONTACT : </b>";	
	 					echo "</td>";
	 					echo "<td>";
	 						echo $field4name;
	 					echo "</td>";
	 				echo "</tr>";

	 				echo "<tr>";
	 					echo "<td>";
	 						echo "<b> FATHER-NAME : </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $field5name;
	 					echo "</td>";
                          echo "</tr>";
                          echo "<tr>";
	 					echo "<td>";
	 						echo "<b> FATHER-CONTACT : </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $field6name;
	 					echo "</td>";
                          echo "</tr>";
                          echo "<tr>";
	 					echo "<td>";
	 						echo "<b> STATE : </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $field7name;
	 					echo "</td>";
                          echo "</tr>";
                          echo "<tr>";
	 					echo "<td>";
	 						echo "<b> CITY : </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $field8name;
	 					echo "</td>";
                          echo "</tr>";
                          echo "<tr>";
	 					echo "<td>";
	 						echo "<b> HOUSE </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $field9name;
	 					echo "</td>";
                          echo "</tr>";
                          echo "<tr>";
	 					echo "<td>";
	 						echo "<b> ID PROOF : </b>";
	 					echo "</td>";
	 					echo "<td>";
	 						echo $field10name;
	 					echo "</td>";
	 				echo "</tr>";

	 				
 				echo "</table>";
                     echo "</b>";
                     echo '</div>';









       
    }

/*freeresultset*/
$result->free();
} 
?>
</body>
</html>