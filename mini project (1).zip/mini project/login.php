<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Student</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>



	<div class="wrapper">
	<nav class="navbar">
			<img src="logoo.png" class="logo">
			<ul>
				<li><a href="homepage.php" class="activ">HOME</a></li>
				<li><a href="prac.php">FEATURES</a></li>
				<li><a href="about.php">ABOUT</a></li>
			</ul>
			
		</nav>
		</div>







	<div class="wrap">
		<form  method="post" action="login.php" onsubmit="return checkPassword(this)">
		<?php include('errors.php') ?>
			<div class="container">
				<i style="text-align: center; margin-top: 6px; border-radius: 40px; " class="fa fa-user-circle icon"></i>
				<h1>Login</h1>
				<h2>(Student)*</h2>
				<hr size="4" width="100%" color="#4caf50">

				<label for="name"><b>username</b></label>
				<input type="text" name="username" id="name" placeholder="First & Last name" value="<?php echo $username; ?>" required>
				<span id="name"></span>
				<lable ><b>Password</b></label>
                <input type="Password" name="password" placeholder="Enter Password">
                <lable ><b> ConformPassword</b></label>
			<button type="submit" class="btn" name="login_user">Login</button>
			<p>
			Not yet a member ? <a href="register.php">Sign Up</a>
		</p>
</body>
</html>