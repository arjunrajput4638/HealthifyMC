<?php include('server.php') ?>



<?php
    $username   = mysqli_real_escape_string($db, $_POST['usernsme']);
    $username2  = mysqli_real_escape_string($db, $_POST['Username']);
    $u1= "SELECT * FROM users WHERE username='$username'";
    $u2 = "SELECT * FROM usersteacher WHERE Username='$username2'";
    if($u1 != $u2){
        array_push($errors, "Wrong username/password combination");
    }
?>